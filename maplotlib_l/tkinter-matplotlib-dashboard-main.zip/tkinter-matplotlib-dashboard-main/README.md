# tkinter-matplotlib-dashboard
Source code for Youtube video: https://youtu.be/2JjQIh-sgHU
